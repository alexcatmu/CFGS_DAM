<?php

$cantidadTires = $_POST['cantidadTires']; 
$cantidadOil = $_POST['cantidadOil']; 
$cantidadSpark = $_POST['cantidadSpark']; 
$opcionSeleccionada = $_POST['opcionSeleccionada'];
$array="";
$posicion = 1;
$aux="";
$fp = fopen("order.txt",'r');

$array=  fgetcsv($fp, 990, "\t");
$tireqty=$array[0];
$oilqty=$array[1];
$sparkqty=$array[2];
$find=$array[3];
$total=$array[4];

while (!feof($fp))
{
    if ($posicion==$opcionSeleccionada)
    {
        $total=$cantidadTires*2+$cantidadOil*5+$cantidadSpark*3;
        $tireqty=$cantidadTires;
        $oilqty = $cantidadOil;
        $sparkqty = $cantidadSpark;
        $total = $total;
    }
    $aux.=$tireqty."\t".$oilqty."\t".$sparkqty."\t".$find."\t".$total."\r\n";
    $posicion = $posicion + 1;   
    
    $array=  fgetcsv($fp, 990, "\t");
    $tireqty=$array[0];
    $oilqty=$array[1];
    $sparkqty=$array[2];
    $find=$array[3];
    $total=$array[4];
}
$mostrarTabla = $aux;;
echo $mostrarTabla;
fclose($fp);

$fp=fopen("order.txt",'w');
fwrite($fp, $aux);
fclose($fp);




?>
